# Tryingtogetthistowork
Ignore this. I'm literally just trying to make a bot that will go online and stay for a while so I can get my existing bot to work again.
